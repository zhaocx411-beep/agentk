import asyncio
import contextlib
from collections.abc import Callable, Sequence
from copy import deepcopy
from typing import Any, Self

from temporalio.client import Client
from temporalio.worker import Worker as TemporalWorker

from ._announce import announce_forever
from ._discovery import describe_activity
from ._manifest import Manifest, build_manifest
from .capability import Capability
from .invocation import _with_invocation_interceptor


class Worker(TemporalWorker):
    """A Temporal worker that also reports a capability manifest.

    Workflows and activities are registered through the native Temporal
    arguments, so the registration surface stays exactly what Temporal shows.
    Publishing a capability adds it to the manifest and nothing else.

    Capability manifests are announced to the AgentK core automatically.
    """

    def __init__(
        self,
        client: Client,
        *,
        task_queue: str,
        workflows: Sequence[type] = (),
        activities: Sequence[Callable] = (),
        **worker_options: Any,
    ) -> None:
        self._workflows: list[Capability] = []
        self._activities: list[Capability] = []
        self._frozen: Manifest | None = None
        self._announcer: asyncio.Task[None] | None = None
        interceptors = _with_invocation_interceptor(
            worker_options.pop("interceptors", ())
        )
        super().__init__(
            client,
            task_queue=task_queue,
            workflows=workflows,
            activities=[*activities, describe_activity(self._frozen_payload)],
            interceptors=interceptors,
            **worker_options,
        )

    def publish_workflow(self, capability: Capability) -> None:
        """Add an already registered workflow to the manifest."""
        self._ensure_mutable()
        self._workflows.append(deepcopy(capability))

    def publish_activity(self, capability: Capability) -> None:
        """Add an already registered activity to the manifest."""
        self._ensure_mutable()
        self._activities.append(deepcopy(capability))

    async def run(self) -> None:
        self._start_announcing()
        try:
            await super().run()
        finally:
            await self._stop_announcing()

    async def shutdown(self) -> None:
        await self._stop_announcing()
        await super().shutdown()

    async def __aenter__(self) -> Self:
        if self._frozen is None:
            self._frozen = self._build()
        return await super().__aenter__()

    def _ensure_mutable(self) -> None:
        if self._frozen is not None:
            raise RuntimeError("capability manifest is frozen after the worker starts")

    def _build(self) -> Manifest:
        return build_manifest(
            self.task_queue,
            workflows=self._workflows,
            activities=self._activities,
        )

    def _frozen_payload(self) -> dict[str, Any]:
        if self._frozen is None:
            raise RuntimeError(
                "capability manifest is not frozen until the worker runs"
            )
        return self._frozen.to_payload()

    def _start_announcing(self) -> None:
        if self._frozen is None:
            self._frozen = self._build()
        manifest = self._frozen
        if self._announcer is not None:
            return
        self._announcer = asyncio.create_task(
            announce_forever(
                self.client,
                worker_task_queue=self.task_queue,
                payload=manifest.to_payload(),
            )
        )

    async def _stop_announcing(self) -> None:
        announcer = self._announcer
        self._announcer = None
        if announcer is None:
            return
        announcer.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await announcer
