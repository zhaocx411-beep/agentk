import json
import math
import re
from collections.abc import Mapping
from dataclasses import dataclass, replace
from datetime import timedelta
from enum import StrEnum
from typing import Any, Literal

JsonObject = Mapping[str, Any]
CapabilityKind = Literal["workflow", "activity"]

_CAPABILITY_ID_PATTERN = re.compile(r"^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$")
_CANONICAL_NAME_PATTERN = re.compile(r"^[a-z][a-z0-9_]{0,127}$")
_MAX_TIMEOUT = timedelta(hours=24)


class ToolMode(StrEnum):
    BLOCKING = "blocking"
    BACKGROUND = "background"


@dataclass(frozen=True, slots=True)
class Artifact:
    type: str
    uri: str
    description: str | None = None
    model: str | None = None
    params: dict[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class Tool:
    name: str
    mode: ToolMode
    description: str | None = None


@dataclass(frozen=True, slots=True)
class Pipeline:
    name: str
    description: str | None = None


@dataclass(frozen=True, slots=True)
class Capability:
    """A workflow or activity contract, plus how it is exposed.

    Kind and task queue come from the publish call and the worker, so they are
    not declared here.
    """

    id: str
    temporal_type: str
    description: str
    input_schema: JsonObject
    output_schema: JsonObject
    timeout: timedelta
    tool: Tool | None = None
    pipeline: Pipeline | None = None


def _normalize_capability(
    capability: Capability,
    *,
    kind: CapabilityKind,
) -> Capability:
    if not isinstance(capability, Capability):
        raise TypeError("capability must be a Capability")
    if kind not in ("workflow", "activity"):
        raise ValueError(f"capability kind is unknown: {kind!r}")
    if (
        len(capability.id) > 128
        or _CAPABILITY_ID_PATTERN.fullmatch(capability.id) is None
    ):
        raise ValueError(
            "capability.id must match <owner>.<snake_case_capability> "
            "and be at most 128 characters"
        )
    _require_non_blank(capability.temporal_type, "capability.temporal_type")
    _require_non_blank(capability.description, "capability.description")

    timeout_seconds = _timeout_seconds(capability.timeout)
    input_schema = _clone_json_object(
        capability.input_schema,
        "capability.input_schema",
    )
    if input_schema.get("type") != "object":
        raise ValueError('capability.input_schema.type must be "object"')
    output_schema = _clone_json_object(
        capability.output_schema,
        "capability.output_schema",
    )

    return replace(
        capability,
        input_schema=input_schema,
        output_schema=output_schema,
        timeout=timedelta(seconds=timeout_seconds),
        tool=_normalize_tool(
            capability.tool,
            kind=kind,
            fallback_description=capability.description,
        ),
        pipeline=_normalize_pipeline(
            capability.pipeline,
            fallback_description=capability.description,
        ),
    )


def _normalize_tool(
    tool: Tool | None,
    *,
    kind: CapabilityKind,
    fallback_description: str,
) -> Tool | None:
    if tool is None:
        return None
    if _CANONICAL_NAME_PATTERN.fullmatch(tool.name) is None:
        raise ValueError(
            "tool.name must start with a lowercase letter and contain only "
            "lowercase letters, digits, or underscores"
        )
    try:
        mode = ToolMode(tool.mode)
    except ValueError as error:
        raise ValueError(f"tool.mode is unknown: {tool.mode!r}") from error
    if mode is ToolMode.BACKGROUND and kind != "workflow":
        raise ValueError("tool.mode background requires a workflow capability")
    description = tool.description
    if description is None:
        description = fallback_description
    else:
        _require_non_blank(description, "tool.description")
    return replace(tool, mode=mode, description=description)


def _normalize_pipeline(
    pipeline: Pipeline | None,
    *,
    fallback_description: str,
) -> Pipeline | None:
    if pipeline is None:
        return None
    if _CANONICAL_NAME_PATTERN.fullmatch(pipeline.name) is None:
        raise ValueError(
            "pipeline.name must start with a lowercase letter and contain "
            "only lowercase letters, digits, or underscores"
        )
    description = pipeline.description
    if description is None:
        description = fallback_description
    else:
        _require_non_blank(description, "pipeline.description")
    return replace(pipeline, description=description)


def _timeout_seconds(timeout: timedelta) -> int:
    if not isinstance(timeout, timedelta):
        raise TypeError("capability.timeout must be a timedelta")
    seconds = timeout.total_seconds()
    if not math.isfinite(seconds) or not seconds.is_integer():
        raise ValueError("capability.timeout must contain whole seconds")
    if timeout <= timedelta(0) or timeout > _MAX_TIMEOUT:
        raise ValueError("capability.timeout must be in (0, 24 hours]")
    return int(seconds)


def _clone_json_object(value: JsonObject, path: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{path} must be a JSON object")
    _validate_json_value(value, path)
    return json.loads(json.dumps(value, allow_nan=False, ensure_ascii=False))


def _validate_json_value(value: Any, path: str) -> None:
    if value is None or isinstance(value, (bool, str, int)):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError(f"{path} must not contain NaN or infinity")
        return
    if isinstance(value, Mapping):
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError(f"{path} must contain only string keys")
            _validate_json_value(item, f"{path}.{key}")
        return
    if isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _validate_json_value(item, f"{path}[{index}]")
        return
    raise ValueError(f"{path} contains a non-JSON value of type {type(value).__name__}")


def _require_non_blank(value: str, path: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{path} is required")
