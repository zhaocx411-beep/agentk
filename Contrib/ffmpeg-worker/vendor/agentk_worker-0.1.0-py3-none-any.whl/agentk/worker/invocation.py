from collections.abc import Mapping, Sequence
from dataclasses import dataclass, replace
from datetime import timedelta
from enum import StrEnum
from typing import Any, NoReturn

from temporalio import workflow
from temporalio.common import RetryPolicy
from temporalio.converter import default
from temporalio.worker import (
    ContinueAsNewInput,
    Interceptor,
    StartActivityInput,
    StartChildWorkflowInput,
    StartLocalActivityInput,
    WorkflowInboundInterceptor,
    WorkflowInterceptorClassInput,
    WorkflowOutboundInterceptor,
)

META_HEADER_KEY = "agentk-invocation-meta-v1"
REPORT_PROGRESS_ACTIVITY_TYPE = "agentk.invocation.progress.v1"

_NON_RETRYABLE_ERROR_TYPES = [
    "NotFound",
    "InvalidArgument",
    "Configuration",
    "PermissionDenied",
    "UpstreamRequestRejected",
]

type JsonValue = (
    None | bool | int | float | str | list[JsonValue] | dict[str, JsonValue]
)


class InvocationKind(StrEnum):
    PIPELINE = "pipeline"
    TOOL = "tool"


@dataclass(frozen=True, slots=True)
class Meta:
    session_id: int
    session: str
    tenant_id: str
    invocation_id: str
    invocation_kind: InvocationKind
    invocation_name: str
    callback_task_queue: str

    def to_payload(self) -> dict[str, JsonValue]:
        return {
            "sessionId": self.session_id,
            "session": self.session,
            "tenantId": self.tenant_id,
            "invocationId": self.invocation_id,
            "invocationKind": self.invocation_kind.value,
            "invocationName": self.invocation_name,
            "callbackTaskQueue": self.callback_task_queue,
        }


@dataclass(frozen=True, slots=True)
class ReportProgressInput:
    session_id: int
    invocation_id: str
    invocation_kind: InvocationKind
    invocation_name: str
    step_id: str
    message: str = ""
    data: JsonValue = None

    @classmethod
    def from_meta(
        cls,
        meta: Meta,
        step_id: str,
        message: str = "",
        data: JsonValue = None,
    ) -> "ReportProgressInput":
        return cls(
            session_id=meta.session_id,
            invocation_id=meta.invocation_id,
            invocation_kind=meta.invocation_kind,
            invocation_name=meta.invocation_name,
            step_id=step_id,
            message=message,
            data=data,
        )

    def to_payload(self) -> dict[str, JsonValue]:
        payload: dict[str, JsonValue] = {
            "sessionId": self.session_id,
            "invocationId": self.invocation_id,
            "invocationKind": self.invocation_kind.value,
            "invocationName": self.invocation_name,
            "stepId": self.step_id,
        }
        if self.message:
            payload["message"] = self.message
        if self.data is not None:
            payload["data"] = self.data
        return payload


def current_meta() -> Meta | None:
    """Return AgentK invocation coordinates for the running workflow, if any."""
    payload = workflow.info().headers.get(META_HEADER_KEY)
    if payload is None:
        return None
    try:
        decoded = default().payload_converter.from_payload(payload)
    except (TypeError, ValueError, RuntimeError):
        return None
    return _decode_meta(decoded)


async def report_progress(
    step_id: str,
    message: str = "",
    data: JsonValue = None,
) -> None:
    """Write a progress event when the workflow was invoked by AgentK."""
    meta = current_meta()
    if meta is None:
        return
    await workflow.execute_activity(
        REPORT_PROGRESS_ACTIVITY_TYPE,
        ReportProgressInput.from_meta(meta, step_id, message, data).to_payload(),
        task_queue=meta.callback_task_queue,
        start_to_close_timeout=timedelta(seconds=30),
        schedule_to_close_timeout=timedelta(minutes=2),
        retry_policy=RetryPolicy(
            initial_interval=timedelta(seconds=1),
            backoff_coefficient=2,
            maximum_interval=timedelta(seconds=10),
            maximum_attempts=3,
            non_retryable_error_types=_NON_RETRYABLE_ERROR_TYPES,
        ),
    )


class _InvocationInterceptor(Interceptor):
    def workflow_interceptor_class(
        self,
        _input: WorkflowInterceptorClassInput,
    ) -> type[WorkflowInboundInterceptor]:
        return _InvocationInboundInterceptor


class _InvocationInboundInterceptor(WorkflowInboundInterceptor):
    def init(self, outbound: WorkflowOutboundInterceptor) -> None:
        self.next.init(_InvocationOutboundInterceptor(outbound))


class _InvocationOutboundInterceptor(WorkflowOutboundInterceptor):
    def continue_as_new(self, input: ContinueAsNewInput) -> NoReturn:
        self.next.continue_as_new(_with_invocation_meta(input))

    def start_activity(
        self,
        input: StartActivityInput,
    ) -> workflow.ActivityHandle[Any]:
        return self.next.start_activity(_with_invocation_meta(input))

    async def start_child_workflow(
        self,
        input: StartChildWorkflowInput,
    ) -> workflow.ChildWorkflowHandle[Any, Any]:
        return await self.next.start_child_workflow(_with_invocation_meta(input))

    def start_local_activity(
        self,
        input: StartLocalActivityInput,
    ) -> workflow.ActivityHandle[Any]:
        return self.next.start_local_activity(_with_invocation_meta(input))


def _with_invocation_meta(input: Any) -> Any:
    payload = workflow.info().headers.get(META_HEADER_KEY)
    if payload is None:
        return input
    return replace(input, headers={**input.headers, META_HEADER_KEY: payload})


def _with_invocation_interceptor(
    interceptors: Sequence[Interceptor],
) -> list[Interceptor]:
    result = list(interceptors)
    if not any(isinstance(item, _InvocationInterceptor) for item in result):
        result.append(_InvocationInterceptor())
    return result


def _decode_meta(value: Any) -> Meta | None:
    if not isinstance(value, Mapping):
        return None
    try:
        session_id = value["sessionId"]
        session = value["session"]
        tenant_id = value["tenantId"]
        invocation_id = value["invocationId"]
        invocation_kind = InvocationKind(value["invocationKind"])
        invocation_name = value["invocationName"]
        callback_task_queue = value["callbackTaskQueue"]
    except (KeyError, TypeError, ValueError):
        return None
    if type(session_id) is not int or session_id < 1:
        return None
    strings = (
        session,
        tenant_id,
        invocation_id,
        invocation_name,
        callback_task_queue,
    )
    if not all(isinstance(item, str) and item for item in strings):
        return None
    return Meta(
        session_id=session_id,
        session=session,
        tenant_id=tenant_id,
        invocation_id=invocation_id,
        invocation_kind=invocation_kind,
        invocation_name=invocation_name,
        callback_task_queue=callback_task_queue,
    )
